// Expose MaterialPhotoGallery to Global Scope
var MaterialPhotoGallery = require('./material-photo-gallery')
window.MaterialPhotoGallery = MaterialPhotoGallery
